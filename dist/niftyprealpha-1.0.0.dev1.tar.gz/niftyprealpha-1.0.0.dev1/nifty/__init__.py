import pipeline.linearPipeline as linearPipeline
import pipeline.nifsSort as nifsSort
import pipeline.nifsBaselineCalibration as nifsBaselineCalibration
import pipeline.nifsReduce as nifsReduce
import pipeline.nifsUtils as nifsUtils

__version__ = "1.0.0"
